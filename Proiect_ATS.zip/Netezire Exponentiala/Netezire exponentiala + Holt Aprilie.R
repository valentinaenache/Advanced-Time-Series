## Librarii necesare
library(tidyverse)
library(fpp2)
library(tsbox)

## Import date
google <- read.csv("GOOG3.csv", header = TRUE, sep = ",")
class(google)
google$Adj_Close <-ts(google$Adj_Close)
google$Adj_Close
class(google$Adj_Close)

### 1. Netezire exponentiala

# alpha = 0.2; forecast forward steps h = 21

google.train <- window(google$Adj_Close, end = 1320)
google.test <- window(google$Adj_Close, start = 1321)
ses.google <- ses(google.train, alpha = .2, h = 21)
autoplot(ses.google)

# eliminarea trendului
google.dif <- diff(google.train)
autoplot(google.dif)

# reaplicarea netezirii exponentiale
ses.google.dif <- ses(google.dif,
                      alpha = .2, 
                      h = 21)
autoplot(ses.google.dif)


# eliminarea trendului din setul de testare
google.dif.test <- diff(google.test)
accuracy(ses.google.dif, google.dif.test)

# compararea previziunii cu setul de validare
# aflarea modelului care minimizeaza RMSE

alpha <- seq(.01, .99, by = .01)
RMSE <- NA
for(i in seq_along(alpha)) {
  fit <- ses(google.dif, alpha = alpha[i],
             h = 90)
  RMSE[i] <- accuracy(fit, 
                      google.dif.test)[2,2]
}

# convertirea in tibble si identificarea alpha minim
alpha.fit <- tibble(alpha, RMSE)
alpha.min <- filter(alpha.fit, 
                    RMSE == min(RMSE))
alpha.fit
alpha.min

# plot RMSE vs. alpha
ggplot(alpha.fit, aes(alpha, RMSE)) +
  geom_line() +
  geom_point(data = alpha.min,
             aes(alpha, RMSE), 
             size = 2, color = "red")

# model cu alpha = .57
ses.google.opt <- ses(google.dif, 
                    alpha = .57,
                    h = 21)

# aflare acuratete
accuracy(ses.google.opt, google.dif.test)

# plot rezultate
p1 <- autoplot(ses.google.opt) +
  theme(legend.position = "bottom")
p2 <- autoplot(google.dif.test) +
  autolayer(ses.google.opt, alpha = .1) +
  ggtitle("Predicted vs. actuals for 
                 the test data set")

gridExtra::grid.arrange(p1, p2, 
                        nrow = 1)


# Aplicarea testului Holt
google.train <- window(google$Adj_Close, end = 1320)
google.test <- window(google$Adj_Close, start = 1321)
holt.google <- holt(google.train,
                  h = 21)
autoplot(holt.google)

# holt's method
holt.google$model

# accuracy of the model
accuracy(holt.google, google.test)

# identify optimal alpha parameter
beta <- seq(.0001, .5, by = .001)
RMSE <- NA
for(i in seq_along(beta)) {
  fit <- holt(google.train,
              beta = beta[i], 
              h = 100)
  RMSE[i] <- accuracy(fit, 
                      google.test)[2,2]
}

# convert to a data frame and
# idenitify min alpha value
beta.fit <- tibble(beta, RMSE)
beta.min <- filter(beta.fit, 
                   RMSE == min(RMSE))
beta.min


# plot RMSE vs. alpha
ggplot(beta.fit, aes(beta, RMSE)) +
  geom_line() +
  geom_point(data = beta.min, 
             aes(beta, RMSE), 
             size = 2, color = "red")

# new model with optimal beta
holt.google.opt <- holt(google.train,
                      h = 21,
                      beta = 0.499)

# accuracy of first model
accuracy(holt.google, google.test)

# accuracy of new optimal model
accuracy(holt.google.opt, google.test)

p3<- autoplot(holt.google) +
  ggtitle("Original Holt's Model") +
  coord_cartesian(ylim = c(400, 2500))
p3

p4<- autoplot(holt.google.opt) +
  ggtitle("Optimal Holt's Model") +
  coord_cartesian(ylim = c(400, 2500))
p4

gridExtra::grid.arrange(p3, p4,
                        nrow = 1)
